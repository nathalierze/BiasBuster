import unittest
from abroca import calculate_abroca

class TestCalculateAbroca(unittest.TestCase):
    
    def test_calculate_abroca(self):
        self.AssertEqual(1,1)

unittest.main()